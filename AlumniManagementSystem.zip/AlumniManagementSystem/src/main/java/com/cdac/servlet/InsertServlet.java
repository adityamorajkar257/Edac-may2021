package com.cdac.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.dao.AlumniDaoImpl;
import com.cdac.dao.Alumnidao;
import com.cdac.entity.Alumni;

public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public InsertServlet() {

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Insert Student
		
		//String id = request.getParameter("id");
		String name = request.getParameter("name");
		String year = request.getParameter("year");
		String course = request.getParameter("course");
		String dept = request.getParameter("dept");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String ph = request.getParameter("ph");
		String organization = request.getParameter("organization");
		
		
		Alumni alumni = new Alumni(name,year,course,dept,email,address,ph,organization);
		
		Alumnidao alumniDao=new AlumniDaoImpl();	
		int alumniInserted = 0;
		alumniInserted = alumniDao.insertAlumni(alumni);
		System.out.println("alumni Inserted: "+alumniInserted);
		
		RequestDispatcher rd = request.getRequestDispatcher("retrive");
		rd.forward(request, response);    //		response.sendRedirect("alumni-list.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}
}