package com.cdac.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cdac.dao.AlumniDaoImpl;
import com.cdac.dao.Alumnidao;
import com.cdac.entity.Alumni;

public class retrieveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public retrieveServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

        // Get All Alumni Records
		Alumnidao alumniDao=new AlumniDaoImpl();
		
		List<Alumni> alumniList = alumniDao.getAllAlumni();
        
		HttpSession session=request.getSession();
		session.setAttribute("alumni", alumniList);
		
		//System.out.println(alumniList);
		
		for (Alumni alumni : alumniList) {
			System.out.println(alumni);
		}
		
		response.sendRedirect("alumni-list.jsp");
	
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}
}