package com.cdac.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.cdac.dao.AlumniDaoImpl;
import com.cdac.dao.Alumnidao;
import com.cdac.entity.Alumni;
import com.cdac.helper.FactoryProvider;

public class updateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public updateServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * String id = request.getParameter("id");
		 * 
		 * int getId=Integer.parseInt(id);
		 * 
		 * 
		 * // Update Alumni Alumni alumni1 = new Alumni();
		 * 
		 * Alumnidao alumniDao=new AlumniDaoImpl();
		 * 
		 * 
		 * boolean noOfAlumniUpdated = alumniDao.updateAlumni(getId);
		 * if(noOfAlumniUpdated) { response.sendRedirect("alumni-list.jsp");
		 * 
		 * } else { System.out.println("no rows updated"); }
		 */
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			String name=request.getParameter("name");
			String year=request.getParameter("year");
			String course=request.getParameter("course");
			String dept=request.getParameter("dept");
			String email=request.getParameter("email");
			String address=request.getParameter("address");
			String ph=request.getParameter("ph");
			String organization=request.getParameter("organization");
			
			int alumniId=Integer.parseInt(request.getParameter("alumniId"));
			
			Session session = FactoryProvider.getFactory().openSession();
			Transaction tx = session.beginTransaction();
			
			Alumni alumni=session.get(Alumni.class, alumniId);
			 alumni.setName(name);
			 alumni.setYear(year);
			 alumni.setCourse(course);
			 alumni.setDept(dept);
			 alumni.setEmail(email);
			 alumni.setAddress(address);
			 alumni.setPh(ph);
			 alumni.setCurrent_Organization(organization);
			
			
			tx.commit();
			session.close();
			
			response.sendRedirect("alumni-list.jsp");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
}