package com.cdac.dao;

import java.util.List;

import com.cdac.entity.Alumni;

public interface Alumnidao {
	public int insertAlumni(Alumni alumni);
	public boolean deleteAlumni(int id);
	public List<Alumni> getAllAlumni();
	public boolean updateAlumni(int getId);
}
