package com.cdac.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cdac.entity.Alumni;

public class AlumniDaoImpl implements Alumnidao {

	public int insertAlumni(Alumni alumni) {

		Configuration config = new Configuration().configure();
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();

		session.save(alumni);
		
		
		transaction.commit();
		session.close();
		return 0;
	}

	public boolean deleteAlumni(int id) {

		Configuration config = new Configuration().configure();
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		
		Alumni alumni = session.get(Alumni.class, id);

		session.delete(alumni);
	
		transaction.commit();
		session.close();
		return true;
	}

	public List<Alumni> getAllAlumni() {
		Configuration config = new Configuration().configure();
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();

		
		Query query=session.createQuery("from Alumni");
		List<Alumni> listAlumni=query.getResultList();
		
		for(Alumni alumni:listAlumni) {
			System.out.println(listAlumni);	
		}
		
		transaction.commit();
		session.close();

		return listAlumni;
	}

	

	public boolean updateAlumni(int getId) {
		Configuration config = new Configuration().configure();
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		
		Alumni alumni = session.get(Alumni.class, getId);

		session.update(alumni);
	
		transaction.commit();
		session.close();


		return true;
	}	
}