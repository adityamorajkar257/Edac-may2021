package com.cdac.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Alumni {
	

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "id")
		private int id;
		
		@Column(name = "name")
		private String name;
		
		@Column(name = "year")
		private String year;
		
		@Column(name = "course")
		private String course;
		
		@Column(name = "dept")
		private String dept;
		
		@Column(name = "email")
		private String email;
		
		@Column(name = "address")
		private String address;
		
		@Column(name = "ph")
		private String ph;
	
		
		@Column(name = "Current_Organization")
		private String Current_Organization;


		public Alumni() {
			super();
			
		}

		public Alumni(String name, String year, String course, String dept, String email, String address, String ph,
				String current_Organization) {
			super();
			this.name = name;
			this.year = year;
			this.course = course;
			this.dept = dept;
			this.email = email;
			this.address = address;
			this.ph = ph;
			Current_Organization = current_Organization;
		}

		public Alumni(int id, String name, String year, String course, String dept, String email, String address,
				String ph, String current_Organization) {
			super();
			this.id = id;
			this.name = name;
			this.year = year;
			this.course = course;
			this.dept = dept;
			this.email = email;
			this.address = address;
			this.ph = ph;
			Current_Organization = current_Organization;
		}


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getYear() {
			return year;
		}


		public void setYear(String year) {
			this.year = year;
		}


		public String getCourse() {
			return course;
		}


		public void setCourse(String course) {
			this.course = course;
		}


		public String getDept() {
			return dept;
		}


		public void setDept(String dept) {
			this.dept = dept;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}


		public String getPh() {
			return ph;
		}


		public void setPh(String ph) {
			this.ph = ph;
		}


		public String getCurrent_Organization() {
			return Current_Organization;
		}


		public void setCurrent_Organization(String current_Organization) {
			Current_Organization = current_Organization;
		}


		@Override
		public String toString() {
			return "Alumni [id=" + id + ", name=" + name + ", year=" + year + ", course=" + course + ", dept=" + dept
					+ ", email=" + email + ", address=" + address + ", ph=" + ph + ", Current_Organization="
					+ Current_Organization + "]";
		}
		
		
}
		
		
		

